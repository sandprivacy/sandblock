'use strict';
/* SandBlock — logique de la page d'options */

(async function () {

const $ = (id) => document.getElementById(id);
const msg = (key) => browser.i18n.getMessage(key);
const nf = new Intl.NumberFormat(browser.i18n.getUILanguage());
const df = new Intl.DateTimeFormat(browser.i18n.getUILanguage(), {
  dateStyle: 'medium',
  timeStyle: 'short',
});

/* i18n */
for (const el of document.querySelectorAll('[data-i18n]')) {
  el.textContent = msg(el.dataset.i18n);
}
$('version').textContent = 'SandBlock v' + browser.runtime.getManifest().version;

/* Rendu */

function renderLists(listsState) {
  const container = $('listsContainer');
  container.textContent = '';
  for (const list of listsState) {
    const row = document.createElement('div');
    row.className = 'list-row';

    const info = document.createElement('div');
    info.className = 'list-info';
    const title = document.createElement('span');
    title.className = 'list-title';
    title.textContent = list.title;
    const meta = document.createElement('span');
    meta.className = 'list-meta';
    meta.textContent =
      `${msg('opt_last_update')} ${list.updated ? df.format(new Date(list.updated)) : msg('opt_never')}` +
      (list.count ? ` — ${nf.format(list.count)} ${msg('opt_rules')}` : '');
    info.append(title, meta);

    const label = document.createElement('label');
    label.className = 'switch';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = list.enabled;
    const slider = document.createElement('span');
    slider.className = 'slider';
    label.append(input, slider);

    input.addEventListener('change', async () => {
      input.disabled = true;
      const res = await browser.runtime.sendMessage({
        type: 'options:setListEnabled',
        id: list.id,
        enabled: input.checked,
      });
      input.disabled = false;
      renderLists(res.lists);
      renderCompileInfo(res.info);
    });

    row.append(info, label);
    container.append(row);
  }
}

function renderCompileInfo(info) {
  $('compileInfo').textContent =
    `${nf.format(info.networkFilters + info.cosmeticFilters)} ${msg('active_filters')} · ${info.ms} ms`;
}

function flash(id) {
  const el = $(id);
  el.textContent = msg('opt_saved');
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 1600);
}

/* Chargement initial */

const state = await browser.runtime.sendMessage({ type: 'options:get' });
$('enabledToggle').checked = state.settings.enabled;
$('cosmeticToggle').checked = state.settings.genericCosmetics;
$('scriptletsToggle').checked = state.settings.scriptlets !== false;
$('totalBlocked').textContent = nf.format(state.totalBlocked);
$('userFilters').value = state.userFilters;
$('whitelist').value = state.whitelist;
renderLists(state.lists);
renderCompileInfo(state.info);

/* Interactions */

$('enabledToggle').addEventListener('change', (ev) => {
  browser.runtime.sendMessage({
    type: 'options:setSetting', key: 'enabled', value: ev.target.checked,
  });
});

$('cosmeticToggle').addEventListener('change', (ev) => {
  browser.runtime.sendMessage({
    type: 'options:setSetting', key: 'genericCosmetics', value: ev.target.checked,
  });
});

$('scriptletsToggle').addEventListener('change', (ev) => {
  browser.runtime.sendMessage({
    type: 'options:setSetting', key: 'scriptlets', value: ev.target.checked,
  });
});

/* ---------------- diagnostic ---------------- */

async function refreshDebug() {
  const d = await browser.runtime.sendMessage({ type: 'debug:get' });
  $('debugToggle').checked = d.enabled;
  $('debugLog').value = d.enabled
    ? (d.count === 0 ? msg('opt_debug_empty') : d.report)
    : msg('opt_debug_off');
  return d;
}

function flashNote(text) {
  const el = $('debugNote');
  el.textContent = text;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 1800);
}

refreshDebug();

$('debugToggle').addEventListener('change', async (ev) => {
  await browser.runtime.sendMessage({ type: 'debug:set', enabled: ev.target.checked });
  await refreshDebug();
});

$('debugRefresh').addEventListener('click', refreshDebug);

$('debugClear').addEventListener('click', async () => {
  await browser.runtime.sendMessage({ type: 'debug:clear' });
  await refreshDebug();
});

$('debugCopy').addEventListener('click', async () => {
  const d = await refreshDebug();
  if (!d.enabled) { flashNote(msg('opt_debug_off')); return; }
  try {
    await navigator.clipboard.writeText(d.report);
    flashNote(msg('opt_debug_copied'));
  } catch (_) {
    $('debugLog').select();
    flashNote(msg('opt_debug_manual'));
  }
});

$('resetStats').addEventListener('click', async () => {
  await browser.runtime.sendMessage({ type: 'options:resetStats' });
  $('totalBlocked').textContent = '0';
});

$('updateBtn').addEventListener('click', async (ev) => {
  const btn = ev.currentTarget;
  btn.disabled = true;
  const original = btn.textContent;
  btn.textContent = msg('updating');
  try {
    const res = await browser.runtime.sendMessage({ type: 'lists:update' });
    renderLists(res.lists);
    renderCompileInfo(res.info);
    btn.textContent = res.failed && res.failed.length ? msg('update_failed') : msg('updated');
  } catch (_) {
    btn.textContent = msg('update_failed');
  }
  setTimeout(() => {
    btn.textContent = original;
    btn.disabled = false;
  }, 2000);
});

$('saveFilters').addEventListener('click', async () => {
  const res = await browser.runtime.sendMessage({
    type: 'options:saveUserFilters',
    text: $('userFilters').value,
  });
  renderCompileInfo(res.info);
  flash('filtersSaved');
});

$('saveWhitelist').addEventListener('click', async () => {
  await browser.runtime.sendMessage({
    type: 'options:saveWhitelist',
    text: $('whitelist').value,
  });
  flash('whitelistSaved');
});

})();
