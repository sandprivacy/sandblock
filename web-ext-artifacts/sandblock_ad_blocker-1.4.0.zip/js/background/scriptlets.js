'use strict';
/**
 * SandBlock — Bibliothèque de scriptlets (##+js)
 *
 * Les scriptlets neutralisent la publicité là où le filtrage réseau est
 * impuissant : quand la pub arrive par la même infrastructure que le
 * contenu (cas YouTube : les métadonnées de pub sont embarquées dans le
 * JSON du lecteur). Ils s'exécutent avant les scripts de la page et
 * purgent / neutralisent les API que la page s'apprête à utiliser.
 *
 * Implémentation Firefox : les patchs sont posés sur
 * `window.wrappedJSObject` via `exportFunction` / `cloneInto` depuis le
 * monde content-script — la voie officielle Mozilla, insensible à la
 * CSP de la page (aucune balise <script> injectée).
 *
 * Ce module (background) génère le code à injecter : les fonctions
 * ci-dessous sont sérialisées via toString() puis exécutées dans le
 * monde content-script par tabs.executeScript à document_start.
 */

(function () {

const SB = (self.SB = self.SB || {});

/* ------------------------------------------------------------------ */
/* Prélude : helpers partagés, évalué une fois par frame               */
/* ------------------------------------------------------------------ */

function PRELUDE() {
  const W = window.wrappedJSObject;
  const ef = (fn) => exportFunction(fn, W);
  const ci = (v) => cloneInto(v, W, { cloneFunctions: true });
  const pageError = (msg) => new W.ReferenceError(String(msg));

  const toRegex = (needle) => {
    if (needle === undefined || needle === null || needle === '') return null;
    const s = String(needle);
    if (s.length > 2 && s.startsWith('/') && s.endsWith('/')) {
      try { return new RegExp(s.slice(1, -1)); } catch (e) { return null; }
    }
    return new RegExp(s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  };
  const matches = (re, s) => re === null || re.test(String(s));

  // Résout une chaîne "a.b.c" ; retourne {obj, prop} du dernier maillon.
  const chain = (root, path) => {
    const parts = String(path).split('.');
    let obj = root;
    for (let i = 0; i < parts.length - 1; i++) {
      obj = obj[parts[i]];
      if (obj === undefined || obj === null) return null;
    }
    return { obj, prop: parts[parts.length - 1] };
  };

  const defineGetterSetter = (obj, prop, getter, setter) => {
    const desc = new W.Object();
    desc.get = ef(getter);
    desc.set = ef(setter || function () {});
    desc.configurable = true;
    W.Object.defineProperty(obj, prop, desc);
  };

  // Suppression de chemins "a.b.c" avec jokers *, [] et [-] (json-prune).
  const isWild = (key) => key === '*' || key === '[]' || key === '[-]';
  const removePath = (obj, parts, i) => {
    if (obj === null || typeof obj !== 'object') return;
    const key = parts[i];
    if (i === parts.length - 1) {
      if (isWild(key)) {
        for (const k of Object.keys(obj)) { try { delete obj[k]; } catch (e) {} }
      } else {
        try { delete obj[key]; } catch (e) {}
      }
      return;
    }
    if (isWild(key)) {
      for (const k of Object.keys(obj)) removePath(obj[k], parts, i + 1);
    } else if (obj[key] !== undefined && obj[key] !== null) {
      removePath(obj[key], parts, i + 1);
    }
  };

  const hasPath = (obj, path) => {
    let o = obj;
    for (const part of String(path).split('.')) {
      if (isWild(part)) return true; // approximation permissive
      if (o === null || typeof o !== 'object' || o[part] === undefined) return false;
      o = o[part];
    }
    return true;
  };

  const prune = (root, rawPaths, rawRequired) => {
    if (root === null || typeof root !== 'object') return root;
    const paths = String(rawPaths || '').split(/\s+/).filter(Boolean);
    if (paths.length === 0) return root;
    const required = String(rawRequired || '').split(/\s+/).filter(Boolean);
    if (required.length !== 0 && !required.some((p) => hasPath(root, p))) return root;
    // Travailler sur l'objet non enveloppé : chaque accès de propriété au
    // travers d'un Xray a un coût, prohibitif sur les gros JSON (YouTube
    // renvoie plusieurs Mo par vidéo).
    const target = (root.wrappedJSObject !== undefined && root.wrappedJSObject !== null)
      ? root.wrappedJSObject
      : root;
    for (const path of paths) removePath(target, path.split('.'), 0);
    return root;
  };

  /* --------------------------------------------------------------
   * Registre de purge JSON partagé.
   *
   * Les listes appliquent plusieurs json-prune à un même site. Emballer
   * JSON.parse une fois par règle produirait autant de parcours complets
   * de l'objet ; on n'installe donc qu'un seul point d'entrée, et chaque
   * règle y dépose sa spécification.
   *
   * Aucun détournement de fetch() : réécrire fetch imposerait de lire le
   * corps entier avant de résoudre la promesse (fetch résout normalement
   * dès les en-têtes) et de reconstruire une Response, dont les en-têtes
   * Content-Length / Content-Encoding deviennent faux. Patcher
   * Response.prototype.json atteint le même résultat sans rien de tout
   * cela : le corps reste géré nativement, on ne transforme que l'objet
   * déjà analysé.
   * ------------------------------------------------------------ */
  const pruneSpecs = [];
  let jsonHooksInstalled = false;

  const runSpecs = (obj, url) => {
    if (obj === null || typeof obj !== 'object') return obj;
    for (let i = 0; i < pruneSpecs.length; i++) {
      const spec = pruneSpecs[i];
      if (url === null && spec.scope === 'response') continue;
      if (url !== null && spec.urlMatch !== null && !spec.urlMatch(url, 'GET')) continue;
      try { prune(obj, spec.paths, spec.required); } catch (e) {}
    }
    return obj;
  };

  const installJsonHooks = () => {
    if (jsonHooksInstalled) return;
    jsonHooksInstalled = true;

    const origParse = W.JSON.parse;
    W.JSON.parse = ef(function (text, reviver) {
      const o = origParse.call(W.JSON, text, reviver);
      return runSpecs(o, null);
    });

    const proto = W.Response && W.Response.prototype;
    if (!proto) return;
    const origJson = proto.json;
    proto.json = ef(function () {
      const res = this;
      let url = '';
      try { url = String(res.url || ''); } catch (e) {}
      return new W.Promise(ef(function (resolve, reject) {
        origJson.call(res).then(
          (o) => { resolve(runSpecs(o, url)); },
          (e) => reject(e)
        );
      }));
    });
  };

  /* --------------------------------------------------------------
   * Registre de constantes forcées (set-constant).
   *
   * Plusieurs règles visent souvent des propriétés d'un même objet pas
   * encore créé — sur YouTube, trois règles ciblent
   * ytInitialPlayerResponse.{playerAds,adPlacements,adSlots}. Chacune
   * doit poser un piège sur `window.ytInitialPlayerResponse` ; sans
   * registre partagé, chaque piège écrase le précédent et seule la
   * dernière règle survit.
   * ------------------------------------------------------------ */
  const constApplies = [];
  const trapped = new Set();

  const setConstant = (propPath, value) => {
    const parts = String(propPath).split('.');
    const apply = () => {
      const link = chain(W, propPath);
      if (link === null) return false;
      try {
        defineGetterSetter(link.obj, link.prop, function () { return value; }, function () {});
        return true;
      } catch (e) { return false; }
    };
    constApplies.push(apply);
    if (apply()) return;

    // Poser le piège sur le premier maillon manquant de la chaîne.
    let obj = W;
    let i = 0;
    while (i < parts.length - 1 && obj[parts[i]] !== undefined && obj[parts[i]] !== null) {
      obj = obj[parts[i]];
      i++;
    }
    if (i >= parts.length - 1 && i >= parts.length) return;
    const key = parts.slice(0, i + 1).join('.');
    if (trapped.has(key)) return; // déjà piégé par une autre règle
    trapped.add(key);
    let stored;
    try {
      defineGetterSetter(obj, parts[i],
        function () { return stored; },
        function (v) {
          stored = v;
          // Rejouer TOUTES les règles en attente, pas seulement la dernière.
          for (let k = 0; k < constApplies.length; k++) {
            try { constApplies[k](); } catch (e) {}
          }
        });
    } catch (e) {}
  };

  const addPruneSpec = (rawPaths, rawRequired, urlMatch, scope) => {
    const paths = String(rawPaths || '').trim();
    if (paths === '') return;
    pruneSpecs.push({
      paths,
      required: String(rawRequired || '').trim(),
      urlMatch: urlMatch || null,
      scope: scope || 'all',
    });
    installJsonHooks();
  };

  /**
   * Plus longue sous-chaîne littérale d'une source d'expression
   * régulière. Sert de pré-filtre : un indexOf écarte instantanément la
   * quasi-totalité des URLs, sans lancer le moteur de regex.
   *
   * Indispensable — les listes contiennent des motifs à quantificateurs
   * paresseux enchaînés (`.+?a.+?b.+?c`) dont le retour sur trace est
   * quadratique voire cubique. Évalués sur chaque requête d'un site qui
   * en émet des milliers avec des URLs de plus de 1 000 caractères, ils
   * gèlent la page pendant des dizaines de secondes.
   */
  const literalOf = (src) => {
    let best = '', cur = '';
    const flush = () => { if (cur.length > best.length) best = cur; cur = ''; };
    for (let i = 0; i < src.length; i++) {
      const c = src[i];
      if (c === '\\') {
        const n = src[i + 1];
        i++;
        if (n === undefined || /[dDwWsSbBnrtfvux0-9kpPAZzQE]/.test(n)) { flush(); continue; }
        cur += n; // caractère échappé littéral : \/ \. \?
        continue;
      }
      if (c === '?' || c === '*') { // rend le caractère précédent optionnel
        if (cur.length !== 0) cur = cur.slice(0, -1);
        flush();
        continue;
      }
      if (/[.+^${}()|[\]]/.test(c)) { flush(); continue; }
      cur += c;
    }
    flush();
    return best.length >= 4 ? best : '';
  };

  // Matcher de conditions "url:x method:GET" / "/re/" / "needle"
  const propsMatcher = (spec) => {
    if (spec === undefined || spec === null || spec === '') return () => true;
    const tests = [];
    for (const c of String(spec).split(/\s+/)) {
      const colon = c.indexOf(':');
      let key = 'url', raw = c;
      if (colon > 0 && /^[a-z]+$/i.test(c.slice(0, colon))) {
        key = c.slice(0, colon).toLowerCase();
        raw = c.slice(colon + 1);
      }
      const re = toRegex(raw);
      const isRe = raw.length > 2 && raw.startsWith('/') && raw.endsWith('/');
      tests.push({ key, re, lit: isRe && re !== null ? literalOf(raw.slice(1, -1)) : '' });
    }
    return (url, method) => {
      for (let i = 0; i < tests.length; i++) {
        const t = tests[i];
        if (t.re === null) continue;
        const value = String(t.key === 'method' ? method : url);
        if (t.lit !== '' && value.indexOf(t.lit) === -1) return false;
        if (!t.re.test(value)) return false;
      }
      return true;
    };
  };

  const emptyBody = (kind) =>
    kind === 'emptyObj' ? '{}' : kind === 'emptyArr' ? '[]' : '';

  return {
    W, ef, ci, pageError, toRegex, matches, chain,
    defineGetterSetter, prune, hasPath, propsMatcher, emptyBody,
    addPruneSpec, setConstant,
  };
}

/* ------------------------------------------------------------------ */
/* Scriptlets                                                          */
/* ------------------------------------------------------------------ */

const IMPL = {};

IMPL['set-constant'] = function (H, propPath, rawValue) {
  if (!propPath) return;
  let value;
  switch (String(rawValue)) {
    case 'undefined': value = undefined; break;
    case 'null': value = null; break;
    case 'true': value = true; break;
    case 'false': value = false; break;
    case 'noopFunc': value = H.ef(function () {}); break;
    case 'trueFunc': value = H.ef(function () { return true; }); break;
    case 'falseFunc': value = H.ef(function () { return false; }); break;
    case '': case "''": case 'emptyString': value = ''; break;
    case '[]': case 'emptyArr': value = H.ci([]); break;
    case '{}': case 'emptyObj': value = H.ci({}); break;
    case 'yes': value = 'yes'; break;
    case 'no': value = 'no'; break;
    default:
      if (/^-?\d+(\.\d+)?$/.test(String(rawValue))) value = Number(rawValue);
      else return;
  }
  H.setConstant(propPath, value);
};

IMPL['json-prune'] = function (H, rawPaths, rawRequired) {
  H.addPruneSpec(rawPaths, rawRequired, null, 'all');
};

IMPL['json-prune-fetch-response'] = function (H, rawPaths, rawRequired, ...vargs) {
  // Option propsToMatch éventuelle, passée en paires clef/valeur.
  let urlMatch = null;
  for (let i = 0; i < vargs.length - 1; i++) {
    if (vargs[i] === 'propsToMatch') urlMatch = H.propsMatcher(vargs[i + 1]);
  }
  H.addPruneSpec(rawPaths, rawRequired, urlMatch, 'response');
};

IMPL['json-prune-xhr-response'] = function (H, rawPaths, rawRequired, ...vargs) {
  let urlMatch = null;
  for (let i = 0; i < vargs.length - 1; i++) {
    if (vargs[i] === 'propsToMatch') urlMatch = H.propsMatcher(vargs[i + 1]);
  }
  // XHR aboutit à un JSON.parse côté page : la purge globale le couvre.
  H.addPruneSpec(rawPaths, rawRequired, urlMatch, 'all');
};

IMPL['no-fetch-if'] = function (H, propsToMatch, responseBody) {
  const W = H.W;
  // Sans critère, ce scriptlet neutraliserait TOUTES les requêtes de la
  // page : on refuse de l'installer.
  if (propsToMatch === undefined || String(propsToMatch).trim() === '') return;
  const origFetch = W.fetch;
  const match = H.propsMatcher(propsToMatch);
  const body = H.emptyBody(responseBody);
  W.fetch = H.ef(function (input, init) {
    let url = '';
    let method = 'GET';
    try {
      url = typeof input === 'string' ? input : String(input && input.url || input);
      method = String((init && init.method) || (input && input.method) || 'GET');
    } catch (e) {}
    if (match(url, method)) {
      return new W.Promise(H.ef(function (resolve) {
        resolve(new W.Response(body, H.ci({ status: 200, statusText: 'OK' })));
      }));
    }
    return origFetch.call(W, input, init);
  });
};

IMPL['no-xhr-if'] = function (H, propsToMatch, responseBody) {
  const W = H.W;
  if (propsToMatch === undefined || String(propsToMatch).trim() === '') return;
  const proto = W.XMLHttpRequest.prototype;
  const origOpen = proto.open;
  const origSend = proto.send;
  const match = H.propsMatcher(propsToMatch);
  const body = H.emptyBody(responseBody);
  const flagged = new WeakMap();
  proto.open = H.ef(function (method, url) {
    try {
      if (match(String(url), String(method))) flagged.set(this, String(url));
      else flagged.delete(this);
    } catch (e) {}
    return origOpen.apply(this, arguments);
  });
  proto.send = H.ef(function () {
    if (!flagged.has(this)) return origSend.apply(this, arguments);
    const xhr = this;
    try {
      H.defineGetterSetter(xhr, 'readyState', function () { return 4; });
      H.defineGetterSetter(xhr, 'status', function () { return 200; });
      H.defineGetterSetter(xhr, 'statusText', function () { return 'OK'; });
      H.defineGetterSetter(xhr, 'responseText', function () { return body; });
      H.defineGetterSetter(xhr, 'response', function () { return body; });
      H.defineGetterSetter(xhr, 'responseURL', function () { return flagged.get(xhr); });
      setTimeout(() => {
        try {
          xhr.dispatchEvent(new W.Event('readystatechange'));
          xhr.dispatchEvent(new W.Event('load'));
          xhr.dispatchEvent(new W.Event('loadend'));
        } catch (e) {}
      }, 1);
    } catch (e) {}
  });
};

IMPL['addEventListener-defuser'] = function (H, type, pattern) {
  const W = H.W;
  const proto = W.EventTarget.prototype;
  const orig = proto.addEventListener;
  const reType = H.toRegex(type);
  const rePattern = H.toRegex(pattern);
  proto.addEventListener = H.ef(function (t, listener) {
    try {
      // Le test de type d'abord : sérialiser le listener coûte cher et
      // addEventListener est appelé des milliers de fois par page.
      if (reType !== null && !reType.test(String(t))) return orig.apply(this, arguments);
      if (rePattern !== null) {
        if (typeof listener !== 'function' || !rePattern.test(String(listener))) {
          return orig.apply(this, arguments);
        }
      } else if (reType === null) {
        return orig.apply(this, arguments); // aucun critère : ne rien neutraliser
      }
      return undefined;
    } catch (e) {}
    return orig.apply(this, arguments);
  });
};

IMPL['abort-on-property-read'] = function (H, propPath) {
  const link = H.chain(H.W, propPath);
  if (link === null) return;
  let stored;
  try { stored = link.obj[link.prop]; } catch (e) {}
  try {
    H.defineGetterSetter(link.obj, link.prop,
      function () { throw H.pageError(propPath); },
      function (v) { stored = v; });
  } catch (e) {}
};

IMPL['abort-on-property-write'] = function (H, propPath) {
  const link = H.chain(H.W, propPath);
  if (link === null) return;
  let stored;
  try { stored = link.obj[link.prop]; } catch (e) {}
  try {
    H.defineGetterSetter(link.obj, link.prop,
      function () { return stored; },
      function () { throw H.pageError(propPath); });
  } catch (e) {}
};

IMPL['abort-current-inline-script'] = function (H, propPath, needle) {
  const link = H.chain(H.W, propPath);
  if (link === null) return;
  let stored;
  try { stored = link.obj[link.prop]; } catch (e) {}
  const re = H.toRegex(needle);
  try {
    H.defineGetterSetter(link.obj, link.prop,
      function () {
        const s = H.W.document.currentScript;
        if (s && !s.src && H.matches(re, String(s.textContent))) {
          throw H.pageError(propPath);
        }
        return stored;
      },
      function (v) { stored = v; });
  } catch (e) {}
};

/* Les corps de IMPL sont sérialisés par toString() : ils ne doivent
 * capturer aucune variable de ce module — tout passe par H ou par les
 * arguments. */

IMPL['prevent-setTimeout'] = function (H, pattern, delay) {
  const W = H.W;
  const orig = W.setTimeout;
  const re = H.toRegex(pattern);
  if (re === null) return; // sans motif, ne rien neutraliser
  const wantDelay = (delay === undefined || delay === '') ? null : String(delay);
  W.setTimeout = H.ef(function (cb, d) {
    try {
      // Comparer le délai (un entier) avant de sérialiser le callback :
      // String(fn) est coûteux et setTimeout est appelé en continu.
      if (wantDelay !== null && String(d) !== wantDelay) return orig.apply(W, arguments);
      if (typeof cb === 'function' && re.test(String(cb))) {
        return orig.call(W, H.ef(function () {}), d);
      }
    } catch (e) {}
    return orig.apply(W, arguments);
  });
};

IMPL['prevent-setInterval'] = function (H, pattern, delay) {
  const W = H.W;
  const orig = W.setInterval;
  const re = H.toRegex(pattern);
  if (re === null) return;
  const wantDelay = (delay === undefined || delay === '') ? null : String(delay);
  W.setInterval = H.ef(function (cb, d) {
    try {
      if (wantDelay !== null && String(d) !== wantDelay) return orig.apply(W, arguments);
      if (typeof cb === 'function' && re.test(String(cb))) {
        return orig.call(W, H.ef(function () {}), d);
      }
    } catch (e) {}
    return orig.apply(W, arguments);
  });
};

IMPL['prevent-window-open'] = function (H, pattern) {
  const W = H.W;
  const orig = W.open;
  const re = H.toRegex(pattern);
  W.open = H.ef(function (url) {
    try {
      if (H.matches(re, String(url === undefined ? '' : url))) return null;
    } catch (e) {}
    return orig.apply(W, arguments);
  });
};

/* ------------------------------------------------------------------ */
/* Alias (noms courts utilisés dans les listes uBO)                    */
/* ------------------------------------------------------------------ */

const ALIASES = {
  'set': 'set-constant',
  'json-prune-fetch': 'json-prune-fetch-response',
  'json-prune-xhr': 'json-prune-xhr-response',
  'aopr': 'abort-on-property-read',
  'aopw': 'abort-on-property-write',
  'acis': 'abort-current-inline-script',
  'acs': 'abort-current-inline-script',
  'abort-current-script': 'abort-current-inline-script',
  'aeld': 'addEventListener-defuser',
  'prevent-addEventListener': 'addEventListener-defuser',
  'prevent-fetch': 'no-fetch-if',
  'prevent-xhr': 'no-xhr-if',
  'nostif': 'prevent-setTimeout',
  'no-setTimeout-if': 'prevent-setTimeout',
  'setTimeout-defuser': 'prevent-setTimeout',
  'nosiif': 'prevent-setInterval',
  'no-setInterval-if': 'prevent-setInterval',
  'nowoif': 'prevent-window-open',
  'window.open-defuser': 'prevent-window-open',
};

function resolveName(rawName) {
  let name = String(rawName || '').trim();
  if (name.endsWith('.js')) name = name.slice(0, -3);
  if (IMPL[name] !== undefined) return name;
  const target = ALIASES[name];
  return target !== undefined ? target : null;
}

/* ------------------------------------------------------------------ */
/* Génération du code d'injection                                      */
/* ------------------------------------------------------------------ */

const PRELUDE_SRC = PRELUDE.toString();

/**
 * @param {Array<{name: string, args: string[]}>} entries
 * @param {boolean} [debug] remonter au background les échecs de scriptlet
 * @returns {string|null} code exécutable dans le monde content-script
 */
function buildCode(entries, debug) {
  const calls = [];
  const names = [];
  for (const entry of entries) {
    const name = resolveName(entry.name);
    if (name === null) continue; // scriptlet non supporté : ignoré
    names.push(name);
    const args = entry.args.map((a) => JSON.stringify(a)).join(',');
    const call = `(${IMPL[name].toString()})(H${args !== '' ? ',' + args : ''})`;
    // Sans mode diagnostic, une erreur reste silencieuse : un scriptlet
    // fautif ne doit jamais empêcher les suivants de s'installer.
    calls.push(debug === true
      ? `try{${call};RUN.push(${JSON.stringify(name)});}` +
        `catch(e){ERR.push(${JSON.stringify(name)}+': '+(e&&e.message||e));}`
      : `try{${call};}catch(e){}`);
  }
  if (calls.length === 0) return null;

  const head = ';(function(){\n' +
    "if(typeof exportFunction!=='function'||!window.wrappedJSObject){" +
    (debug === true
      ? "try{browser.runtime.sendMessage({type:'debug:scriptlets',error:'monde page inaccessible'});}catch(e){}"
      : '') +
    'return;}\n' +
    (debug === true ? 'var RUN=[],ERR=[];\n' : '') +
    `var H=(${PRELUDE_SRC})();\n` +
    // Marqueur de diagnostic : prouve que l'écriture dans le monde de la
    // page aboutit réellement, et dans QUEL document.
    (debug === true
      ? 'try{H.W.__sandblockMark=(H.W.__sandblockMark||0)+1;' +
        'H.W.__sandblockDoc=String(location.href).slice(0,120);}' +
        "catch(e){ERR.push('marqueur: '+(e&&e.message||e));}\n"
      : '');

  const tail = debug === true
    ? "\ntry{browser.runtime.sendMessage({type:'debug:scriptlets'," +
      'url:location.href,ran:RUN,errors:ERR});}catch(e){}\n})();'
    : '\n})();';

  return head + calls.join('\n') + tail;
}

/* Cache hostname -> code (invalidé à chaque recompilation) */
const codeCache = new Map();
let debugMode = false;

function setDebug(on) {
  if (debugMode === on) return;
  debugMode = on;
  codeCache.clear(); // le code injecté diffère selon le mode
}

function codeForHostname(hostname) {
  const cached = codeCache.get(hostname);
  if (cached !== undefined) return cached;
  const entries = SB.cosmetic.scriptletsFor(hostname);
  const code = entries.length !== 0 ? buildCode(entries, debugMode) : null;
  if (codeCache.size >= 200) {
    codeCache.delete(codeCache.keys().next().value);
  }
  codeCache.set(hostname, code);
  return code;
}

function clearCache() {
  codeCache.clear();
}

SB.scriptlets = { buildCode, codeForHostname, clearCache, resolveName, setDebug };

})();
