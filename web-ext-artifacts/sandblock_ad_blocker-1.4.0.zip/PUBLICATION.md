# Publier SandBlock sur addons.mozilla.org

Tout ce qui suit est prêt à copier-coller. Le paquet à téléverser est
produit par `npx web-ext build` dans `web-ext-artifacts/`.

---

## 1. Notes au relecteur (champ « Notes for Reviewer »)

**À remplir impérativement.** Un bloqueur de publicité déclenche deux
signaux d'alerte automatiques chez les relecteurs AMO ; les ignorer
rallonge la validation de plusieurs semaines. Copier tel quel :

```
SandBlock is a content blocker, architecturally similar to uBlock Origin
(MIT). Two points that typically raise questions during review:

1. NO REMOTE CODE EXECUTION.
   The extension downloads filter LISTS (EasyList, EasyPrivacy, uAssets)
   at runtime. These are DATA, never code: each line is parsed into an
   internal filter object by js/background/snf.js and
   js/background/cosmetic.js. Nothing from a downloaded list is ever
   passed to eval(), new Function(), or injected as a <script> tag.

2. ABOUT tabs.executeScript({code}) IN js/background/main.js.
   This injects "scriptlets" (the ##+js(...) filter syntax). The
   executable code comes EXCLUSIVELY from the bundled library in
   js/background/scriptlets.js — a fixed set of ~12 functions written by
   us and shipped inside the add-on. Filter lists can only:
     (a) select which of those bundled functions runs, by name — any
         unknown name is rejected at compile time
         (see resolveName() and _parseScriptlet());
     (b) supply string arguments, which are serialized with
         JSON.stringify() before being embedded (see buildCode()).
   The generated code is injected into the CONTENT SCRIPT world and
   patches the page via wrappedJSObject/exportFunction, the documented
   Mozilla mechanism. No <script> element is ever created in the page.

DATA COLLECTION: none. The add-on has no analytics, no telemetry, no
network calls other than fetching the public filter lists listed in
js/background/lists.js. All state is local (storage.local).

PERMISSIONS RATIONALE:
  webRequest + webRequestBlocking + <all_urls> — required to cancel or
    redirect ad/tracker requests before they are sent; this is the core
    function of the add-on and cannot be done with declarativeNetRequest
    without losing dynamic filtering.
  webNavigation — to inject scriptlets at document_start on committed
    navigations.
  tabs — to inject cosmetic CSS (insertCSS with cssOrigin:"user") into
    the correct frame and to show a per-tab blocked-request counter.
  storage + unlimitedStorage — to cache filter lists (~10 MB of text).
  alarms — to refresh the filter lists every 24 hours.

SOURCE CODE: the submitted package is the complete, unmodified source.
There is no build step, no bundler, no minification and no obfuscation.
```

---

## 2. Champs de la fiche

**Nom** : `SandBlock — Ad Blocker`

**Résumé / Summary** (250 caractères max) :

> Ultra-fast, elegant ad & tracker blocker. Token-indexed filtering engine,
> EasyList compatible, YouTube ad scriptlets, zero data collection.

**Description** — version anglaise :

```
SandBlock blocks ads and trackers before they are even requested.

WHY IT'S FAST
A static network filtering engine indexes every filter under its most
discriminating token, so out of 120,000+ filters, only a handful are ever
evaluated per request. Average matching latency: ~11 microseconds.

WHAT IT BLOCKS
• Ad and tracker network requests (EasyList, EasyPrivacy, uAssets, Liste FR)
• Ad placeholders, via CSS element hiding
• YouTube video ads, via scriptlets that strip ad metadata from the player
• Tracking parameters in URLs (fbclid, gclid, utm_*, and 120 more)

BUILT NOT TO BREAK SITES
Cosmetic rules are validated before use: any selector able to reach the
document root or match arbitrary elements is rejected. Generic rules are
served on demand, based on the classes actually present in the page,
instead of being dumped wholesale onto every site.

PRIVACY
No accounts, no analytics, no telemetry, no data collection of any kind.
Everything runs locally on your device. Open source.
```

**Description** — version française :

```
SandBlock bloque les publicités et les traqueurs avant même leur requête.

POURQUOI C'EST RAPIDE
Le moteur de filtrage indexe chaque filtre sous son token le plus
discriminant : sur plus de 120 000 filtres, seule une poignée est évaluée
à chaque requête. Latence moyenne : ~11 microsecondes.

CE QUI EST BLOQUÉ
• Requêtes publicitaires et de pistage (EasyList, EasyPrivacy, uAssets, Liste FR)
• Emplacements publicitaires, par masquage CSS
• Publicités vidéo YouTube, via des scriptlets qui purgent les métadonnées
  de pub du lecteur
• Paramètres de pistage dans les URLs (fbclid, gclid, utm_*, et 120 autres)

CONÇU POUR NE PAS CASSER LES SITES
Les règles cosmétiques sont validées avant usage : tout sélecteur capable
d'atteindre la racine du document ou de viser des éléments arbitraires est
rejeté. Les règles génériques sont servies à la demande, selon les classes
réellement présentes dans la page.

CONFIDENTIALITÉ
Aucun compte, aucune analyse d'audience, aucune télémétrie, aucune collecte
de données. Tout fonctionne localement. Open source.
```

**Catégories** : `Privacy & Security` (principale), `Other`
**Étiquettes** : `adblock`, `ads`, `privacy`, `tracking`, `youtube`
**Licence** : au choix — GPL-3.0 recommandée (cohérente avec l'écosystème
des listes de filtres et de uBlock Origin).

---

## 3. Politique de confidentialité (champ « Privacy Policy »)

```
SandBlock does not collect, transmit, or sell any personal data.

The add-on makes no network requests other than periodically downloading
public filter lists (EasyList, EasyPrivacy, Liste FR, Peter Lowe's list,
uAssets) from their official URLs. These requests contain no identifier
and no information about the pages you visit.

All settings, filter caches and counters are stored locally on your device
using the browser's storage API, and are never sent anywhere. Uninstalling
the add-on removes them.
```

---

## 4. Captures d'écran

AMO en demande au moins une (1280×800 recommandé). Les deux plus utiles :

1. Le popup ouvert sur un site connu, compteur visible.
2. La page de réglages (`about:addons` → SandBlock → Préférences), qui
   montre les listes et leur date de mise à jour.

Sur Windows : `Alt + Impr. écran` capture la fenêtre active.

---

## 5. Points de vigilance

- **`strict_min_version` vaut `142.0`**, requis par la clé
  `data_collection_permissions` (obligatoire pour toute nouvelle
  extension). Cela exclut les utilisateurs d'ESR 140. Pour les inclure,
  descendre à `140.0` : `web-ext lint` émettra alors un avertissement sur
  Firefox pour Android, sans bloquer la soumission.
- **MV2 reste accepté** par Mozilla, contrairement à Chrome. Ne pas migrer
  vers MV3 : cela ferait perdre `webRequestBlocking`, donc l'essentiel du
  blocage.
- **Ne jamais réutiliser un numéro de version.** AMO refuse un `version`
  déjà soumis, même après suppression. Incrémenter dans `manifest.json`
  avant chaque nouveau `web-ext build`.
- **Délai de validation** : publication immédiate après un contrôle
  automatique, puis revue humaine sous quelques jours à quelques semaines
  pour une extension à permissions larges.
